import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ChkUserServiceService {
  private id_of_user;
  private message = new BehaviorSubject(false);
  sharedMessage = this.message.asObservable();

  constructor() { }

  isRoot(message: boolean) {
    this.message.next(message)
  }
  setValue(key: string, value: any): void {
    //sessionStorage.setItem(key, JSON.stringify(value));
    localStorage.setItem(key, JSON.stringify(value));
}
  // public setValue(id_of_user){
  //   this.id_of_user = id_of_user;
    
  // }
  getValue(key: string): any {
    if (typeof window !== 'undefined') {
        //let retrievedObject = sessionStorage.getItem(key) as string;
        let retrievedObject = localStorage.getItem(key) as string;
        return retrievedObject;
    }
}
clearSession(): void {
  localStorage.clear();
}
  // public getValue(){
  //   return this.id_of_user;
  // }
}
