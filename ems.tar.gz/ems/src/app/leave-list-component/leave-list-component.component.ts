import { Component, OnInit } from '@angular/core';
import { AuthservicesService } from '../authservices.service'
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-leave-list-component',
  templateUrl: './leave-list-component.component.html',
  styleUrls: ['./leave-list-component.component.css']
})
export class LeaveListComponentComponent implements OnInit {
  id: any;
  from_date: any;
  leaveDetails: any=[];
  dummy_data: any;
  empName: any;
  empNm: any;
  f_date: any;
  t_date: any;
  lastNm: any;

  constructor(public authser: AuthservicesService,private datePipe: DatePipe) { }

  ngOnInit(): void {
    this.loadLeaves()
  }

loadLeaves() {
    this.authser.loadLeaves().subscribe(data => {
      console.log(data)
      let res: any = data;
      var arrayData = res['data'];
      console.log("arrayData",arrayData)
      for (var i = 0; i < arrayData.length; i++) {
        console.log("empNm", arrayData[i][1])
        console.log("from date", arrayData[i][2])
        console.log("to date", arrayData[i][3])

      this.id = arrayData[i][0]
       var emp_name = arrayData[i][1];
     
       this.f_date = arrayData[i][2]
       var from_date = this.datePipe.transform(this.f_date,"dd-MM-yyyy");

       this.t_date = arrayData[i][3]
       var to_date = this.datePipe.transform(this.t_date,"dd-MM-yyyy");
     
        this.authser.getUserById(emp_name).subscribe(data => {
        
          this.empName = data["data"]
          this.empNm = this.empName["first_name"]
          this.lastNm = this.empName["last_name"]
         
          
        
        
        var obj = {
          "id": this.id,
          "first_name": this.empNm,
          "last_name": this.lastNm,
          "from_date": from_date,
          "to_date": to_date
        }

        console.log("obj",obj)
        this.leaveDetails.push(obj)
      })


      }
    })
    
  }
}
