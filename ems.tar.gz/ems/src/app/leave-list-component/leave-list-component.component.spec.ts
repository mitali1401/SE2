import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LeaveListComponentComponent } from './leave-list-component.component';

describe('LeaveListComponentComponent', () => {
  let component: LeaveListComponentComponent;
  let fixture: ComponentFixture<LeaveListComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LeaveListComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LeaveListComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
