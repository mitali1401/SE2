import { Component, OnInit } from '@angular/core';
import { AuthservicesService } from '../authservices.service'
import { HttpClient, HttpHeaders } from '@angular/common/http';
@Component({
  selector: 'app-user-group-info',
  templateUrl: './user-group-info.component.html',
  styleUrls: ['./user-group-info.component.css']
})
export class UserGroupInfoComponent implements OnInit {
  userGroupInfo: any = []
  userName: any;
  unm: any;
  dummy_data = []
  empName: any;
  empNm: any;
  lastNm: any;
  constructor(private http: HttpClient,
    public authser: AuthservicesService) { }

  ngOnInit(): void {
    // this.loadUserGroupsInfo();
  }
  loadUserGroupsInfo(gid) {
    this.userGroupInfo = [];
    this.authser.getUserGroupInfo(gid).subscribe((data: {}) => {
      console.log(data);
      let res: any = data;
      var arrayData = res['data'];
      console.log("arrayData", arrayData);
      var emp_name = arrayData["emp_id"]
      console.log("emp_name", emp_name);

      this.authser.getUserById(emp_name).subscribe(data => {
        //console.log("empName", data)
        this.empName = data["data"]
        this.empNm = this.empName["first_name"]
        this.lastNm = this.empName["last_name"]

        console.log("empNm", this.empNm)
        console.log("lastNm", this.lastNm)

        var obj = {

          "first_name": this.empNm,
          "last_name": this.lastNm,

        }

        console.log("obj", obj)
        this.userGroupInfo.push(obj)
        console.log("userGroupInfo", this.userGroupInfo)
      })
    })

  }




}


