import { Component, OnInit, Input } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthservicesService } from '../authservices.service'
import { ChkUserServiceService } from '../chk-user-service.service'

@Component({
  selector: 'app-attendance-component',
  templateUrl: './attendance-component.component.html',
  styleUrls: ['./attendance-component.component.css']
})
export class AttendanceComponentComponent implements OnInit {
  @Input() attendance = { emp_id: '', attend_date: '' }
  message: boolean;
  u_id: any;
  constructor(public authser: AuthservicesService, public chkUser: ChkUserServiceService) { }
  ngOnInit(): void {
    this.getEmpId()
  }

  getEmpId() {
   // console.log("get val in attendance ", this.chkUser.getValue('UserId'))
    this.u_id = this.chkUser.getValue('UserId');
    console.log("id in attendance", this.u_id)

  }
  addAttendance() {
    console.log("this.u_id in attendance", this.u_id)
    console.log("this.attendance.emp_id in attendance", this.attendance.emp_id)

    
    var id = parseInt(this.u_id);
    var empid = parseInt(this.attendance.emp_id)

    var empid1 =  String(this.attendance.emp_id)

    console.log("after parsing")
    
    console.log(" this.u_id in attendance", this.u_id)


    console.log(" empid1 in attendance", empid1)
   
    
   
    if (id == empid) {
      console.log("id in attendance if ", id)
      console.log("emp_id in attendance if", empid)
      this.authser.addAttendance(this.attendance.emp_id, this.attendance.attend_date).subscribe(data => {
        console.log(data)
        this.reset()
      })
    }
    else {
      console.log("id in attendance in else", this.u_id)
      console.log("emp_id in attendance in else", this.attendance.emp_id)

      alert("This is not your employee id..!!")
      this.reset();
    }
  }
  reset() {
    this.attendance.emp_id = '',
      this.attendance.attend_date = ''
  }
}
