import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-side-component',
  templateUrl: './user-side-component.component.html',
  styleUrls: ['./user-side-component.component.css']
})
export class UserSideComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
