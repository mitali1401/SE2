import { Component, OnInit, Input } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthservicesService } from '../authservices.service'
import {ChkUserServiceService} from '../chk-user-service.service'
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {

  public result;
  @Input() userInfo = { id: '', password: '' };
  emp_id: any;
  msg: any;
  empId: string;
  empPassword: string;


  public constructor(private http: HttpClient,  public router: Router, public authSer: AuthservicesService,public chkUser : ChkUserServiceService) { }

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/son'
    })
  }



  ngOnInit() {

  }
  signUpuser() {

    this.chkUser.setValue('UserId',this.userInfo.id);
   // console.log("get val",this.chkUser.getValue('UserId'))

    if (this.userInfo.id == "root" && this.userInfo.password == "admin") {
      this.router.navigate(['/homepage']);
    }
    else {
      this.empId = this.userInfo.id;
      this.empPassword = this.userInfo.password



      this.authSer.getUserById(this.userInfo.id).subscribe(data => {
        console.log("data", data);
        let res = data["data"];
        console.log("res", res);


        if (res != undefined) {
          this.msg = res["message"]

          this.emp_id = res["id"]

          var emp_password = res["password"]

          if (this.msg == undefined) {
            if (this.empId == this.emp_id && this.empPassword == emp_password) {

              this.router.navigate(['/userForm']);
            }
            else {
              alert("invalid credential....!!")

            }
          }


        }
        if (res == undefined) {

          alert("you are not registerd....!!")

        }
      })


    }
  }


}
