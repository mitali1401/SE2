import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { AuthservicesService } from '../authservices.service'

@Component({
  selector: 'app-task-group-component',
  templateUrl: './task-group-component.component.html',
  styleUrls: ['./task-group-component.component.css']
})
export class TaskGroupComponentComponent implements OnInit {

  constructor(public router: Router,
    public authser: AuthservicesService) { }

  ngOnInit(): void {
  }
  @Input() taskGroup = {
    gid: '',
    tsk_id: '',


  };

  post() {

    this.authser.createTaskGroup(this.taskGroup.gid,this.taskGroup.tsk_id).subscribe(res => {
      console.log(res);
      
      alert("task created for group...!!!");
      this.reset();

    })

  }

  reset(){
    this.taskGroup.gid = '',
    this.taskGroup.tsk_id =''
  }
}
