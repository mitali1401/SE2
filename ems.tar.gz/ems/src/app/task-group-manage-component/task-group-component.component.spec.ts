import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TaskGroupComponentComponent } from './task-group-component.component';

describe('TaskGroupComponentComponent', () => {
  let component: TaskGroupComponentComponent;
  let fixture: ComponentFixture<TaskGroupComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TaskGroupComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaskGroupComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
