import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChkQueryComponentComponent } from './chk-query-component.component';

describe('ChkQueryComponentComponent', () => {
  let component: ChkQueryComponentComponent;
  let fixture: ComponentFixture<ChkQueryComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChkQueryComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChkQueryComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
