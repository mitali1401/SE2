import { Component, OnInit, Input } from '@angular/core';
import { AuthservicesService } from '../authservices.service'
import { HttpClient, HttpHeaders } from '@angular/common/http';
@Component({
  selector: 'app-chk-query-component',
  templateUrl: './chk-query-component.component.html',
  styleUrls: ['./chk-query-component.component.css']
})
export class ChkQueryComponentComponent implements OnInit {

  constructor(public authser: AuthservicesService) { }
  @Input() query = {
    emp_id: '',
    comment: '',


  };
  ngOnInit(): void {
  }
  ReplyToQuery() {
    //this.authser.ReplyToQuery( ).subscribe((data: {}) => {

     // console.log(data)
     // this.reset();
   // })
  }
  reset(){
    this.query.emp_id ='',
    this.query.comment =''
  }
}
