import { Component, OnInit, Input } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthservicesService } from '../authservices.service'

@Component({
  selector: 'app-task-component',
  templateUrl: './task-component.component.html',
  styleUrls: ['./task-component.component.css']
})
export class TaskComponentComponent implements OnInit {

  constructor(public authser: AuthservicesService) { }
  @Input () task ={ task_name :'',comment :''}

  ngOnInit(): void {
  }

  addTask(){
   
    this.authser.addTask(this.task.task_name,this.task.comment).subscribe(data =>{
     console.log(data);
     this.reset();
    })
  }
  reset(){
    this.task.task_name = '',
    this.task.comment = ''
  }
}
