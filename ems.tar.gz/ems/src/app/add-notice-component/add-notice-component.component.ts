import { Component, OnInit, Input } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthservicesService } from '../authservices.service'

@Component({
  selector: 'app-add-notice-component',
  templateUrl: './add-notice-component.component.html',
  styleUrls: ['./add-notice-component.component.css']
})
export class AddNoticeComponentComponent implements OnInit {

  constructor(public authser: AuthservicesService) { }

  ngOnInit(): void {
  }
  @Input() notice ={
    info:''
  }
  addNotice(){
    this.authser.addNotice(this.notice.info).subscribe(data =>{
      console.log(data)
      this.reset()
    })
  }
  reset(){
    this.notice.info = ''
    
  }
}
