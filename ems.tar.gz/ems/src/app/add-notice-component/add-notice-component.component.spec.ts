import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddNoticeComponentComponent } from './add-notice-component.component';

describe('AddNoticeComponentComponent', () => {
  let component: AddNoticeComponentComponent;
  let fixture: ComponentFixture<AddNoticeComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddNoticeComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddNoticeComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
