import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetTaskComponentComponent } from './get-task-component.component';

describe('GetTaskComponentComponent', () => {
  let component: GetTaskComponentComponent;
  let fixture: ComponentFixture<GetTaskComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetTaskComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetTaskComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
