import { Component, OnInit, Input } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthservicesService } from '../authservices.service'
import {ChkUserServiceService} from '../chk-user-service.service'

@Component({
  selector: 'app-get-task-component',
  templateUrl: './get-task-component.component.html',
  styleUrls: ['./get-task-component.component.css']
})
export class GetTaskComponentComponent implements OnInit {
  message:boolean;
  u_id :any;
  Employee : any [];
  constructor(public authser: AuthservicesService,public chkUser : ChkUserServiceService) { }

  ngOnInit(): void {
   this.getEmpId();
 }

 getEmpId(){
  console.log("get val is task ",this.chkUser.getValue('UserId'))
    this.u_id =this.chkUser.getValue('UserId');
    console.log("id in task",this.u_id)

 }
 sendToReview(){
   alert("responce is added");
 }
}
