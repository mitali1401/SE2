import { TestBed } from '@angular/core/testing';

import { ChkUserServiceService } from './chk-user-service.service';

describe('ChkUserServiceService', () => {
  let service: ChkUserServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ChkUserServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
