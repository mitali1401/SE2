import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-side-component',
  templateUrl: './side-component.component.html',
  styleUrls: ['./side-component.component.css']
})
export class SideComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
