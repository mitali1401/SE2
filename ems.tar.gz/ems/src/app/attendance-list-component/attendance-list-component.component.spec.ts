import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AttendanceListComponentComponent } from './attendance-list-component.component';

describe('AttendanceListComponentComponent', () => {
  let component: AttendanceListComponentComponent;
  let fixture: ComponentFixture<AttendanceListComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AttendanceListComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AttendanceListComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
