import { Component, OnInit } from '@angular/core';
import { AuthservicesService } from '../authservices.service'
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { DatePipe } from '@angular/common';
@Component({
  selector: 'app-attendance-list-component',
  templateUrl: './attendance-list-component.component.html',
  styleUrls: ['./attendance-list-component.component.css']
})
export class AttendanceListComponentComponent implements OnInit {
  attendance: any = []
  empName: any;
  empNm: any;
  attendanceDetails: any = [];
  id: any;
  attend_date: any;
  dummy_data: any;
  lastNm: any;
  constructor(public authser: AuthservicesService,private datePipe: DatePipe) { }

  ngOnInit(): void {
    this.loadAttendance()
  }
  loadAttendance() {
    this.authser.loadAttendance().subscribe(data => {
      console.log(data)
      let res: any = data;
      var arrayData = res['data'];
      for (var i = 0; i < arrayData.length; i++) {

        var emp_name = arrayData[i][1];
        console.log("emp_name", emp_name)
        this.id = arrayData[i][0]
        this.attend_date = arrayData[i][2]
        var ddMMyyyy = this.datePipe.transform(this.attend_date,"dd-MM-yyyy");
        console.log("ddMMyyyy", ddMMyyyy)
        this.authser.getUserById(emp_name).subscribe(data => {
          //console.log("empName", data)
          this.empName = data["data"]
          this.empNm = this.empName["first_name"]
          this.lastNm = this.empName["last_name"]

          console.log("empNm", this.empNm)
          this.dummy_data = this.empNm;
          // arrayData[i][2] = this.empNm;
        
        
        var obj = {
          "id": this.id,
          "first_name": this.dummy_data,
          "last_name": this.lastNm,
          "attend_date": ddMMyyyy
        }

        console.log("obj",obj)
        this.attendanceDetails.push(obj)
      })


      }
    })
    
  }
}

