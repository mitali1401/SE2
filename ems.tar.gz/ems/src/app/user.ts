export interface User {
    id : string ;

	password  :string
}
